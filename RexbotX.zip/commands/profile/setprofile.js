const {
    monospace,
    quote
} = require("@mengkodingan/ckptw");
    
module.exports = {
    name: "setprofile",
    aliases: ["set", "setp", "setprof"],
    category: "profile",
    permissions: {},
    code: async (ctx) => {
        const input = ctx.args.join(" ") || null;

        if (!input) return await ctx.reply(
            `${quote(`${tools.msg.generateInstruction(["send"], ["text"])}`)}\n` +
            `${quote(tools.msg.generateCommandExample(ctx.used, "autolevelup"))}\n` +
            quote(tools.msg.generateNotes([`Ketik ${monospace(`${ctx.used.prefix + ctx.used.command} list`)} untuk melihat daftar.`]))
        );

        if (ctx.args[0] === "list") {
            const listText = await tools.list.get("setprofile");
            return await ctx.reply(listText);
        }

        try {
            const senderId = tools.general.getID(ctx.sender.jid);
            const userDb = await Database.getUser(senderId);

            switch (input.toLowerCase()) {
                case "autolevelup":
                    const newStatus = !(userDb?.autolevelup || false);
                    await Database.updateUser(senderId, {
                        autolevelup: newStatus
                    });
                    const statusText = newStatus ? "diaktifkan" : "dinonaktifkan";
                    return await ctx.reply(quote(`✅ Fitur '${input}' berhasil ${statusText}!`));
                default:
                    return await ctx.reply(quote(`❎ Teks tidak valid.`));
            }
        } catch (error) {
            consolefy.error(`Error: ${error}`);
            return await ctx.reply(quote(`⚠️ Terjadi kesalahan: ${error.message}`));
        }
    }
};